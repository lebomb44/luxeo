PIN532_SPI lib for NFC shield Modify
//---------------------------------
This version works on Arduino 1.0 IDE and compatiable with MEGA1280 and MEGA2560.
1.Modify _ss in PIN532.cpp because in this file _ss is used to be a pin to select the PIN532 chip which is linked to pin10 on the main board,and SS pin of the MEGA1280 and MEGA2560 is pin53
2.SPI pins are not the same between MEGA1280 and ATmega328 so the pin macro definitions should be changed in .ino file.

2012.02.09 by Frankie in seeed.